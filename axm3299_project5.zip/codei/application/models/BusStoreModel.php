<?php

	Class BusStoreModel extends CI_Model{

		Public function __construct() 
		{ 
        	parent::__construct(); 
      	}

		public function insertService($data) 
		{ 
			$this->db->where($data[1]);
    		$this->db->update($business, $data[0]);
    	}

	}
?>