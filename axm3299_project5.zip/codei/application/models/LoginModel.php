<?php 
   Class LoginModel extends CI_Model { 
		Public function __construct() { 
        	parent::__construct(); 
      	}

      	public function getLogin($email) 
		    { 
        	$this->db->select('pwd','rollid');
        	$this->db->where('email',$email); 
        	$this->db->get('login');

          $result=$query->result();
          $num_rows=$query->num_rows();

          if ($result[0] == '55555' && $result[1] == '0') 
          {
             $this->load->view('Client');
          } 

          elseif ($result[0] == '55555' && $result[1] == '1') 
          {
             $this->load->view('BusStore');
          }

          else
          {
            header("Location:login.php");
            echo '<script language="javascript">';
            echo 'alert("Login credentials are incorrect")';
            echo '</script>';
          }

    	  }


		
       
 } 
?> 



