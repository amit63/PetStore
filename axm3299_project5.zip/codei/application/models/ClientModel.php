<?php

	Class ClientModel extends CI_Model{

		Public function __construct() 
		{ 
        	parent::__construct(); 
      	}

		public function insertClient($data) 
		{ 
			$this->db->insert('clients', $data);	 
    	}

    	public function insertClientLogin($dataLogin) 
		{ 
			$this->db->insert('login', $dataLogin);
        		 
    	}

	}
?>