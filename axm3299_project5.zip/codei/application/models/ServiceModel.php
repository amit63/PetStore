<?php

	Class ServiceModel extends CI_Model{

		Public function __construct() 
		{ 
        	parent::__construct(); 
      	}

		public function insertService($data) 
        { 
            $this->db->insert('clients', $data);     
        }

        public function insertServiceLogin($dataLogin) 
        { 
            $this->db->insert('login', $dataLogin);
                 
        }

	}
?>