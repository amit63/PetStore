<?php
		class contactModel extends CI_Model{
		function __construct() {
			parent::__construct();
		}

		function insertContact($data){
			$this->db->insert('contacts', $data);
		}
	}
?>