<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/pet.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Client's Pet Store</title>
</head>
<body>
	<div id="wrapper">
	<h1>Client's Pet Store</h1>
		<div class = "row">
			<div class = "column left">
				<nav>
					<ul>

      <li><a href="Home">Home</a></li>
        <li><a href="AboutUs">About Us</a></li>
        <li><a href="ContactUs">Contact Us</a></li>
        <li><a href="Client">Client</a></li>
        <li><a href="Service">Service</a></li>
        <li><a href="Login">Login</a></li>
		
		</ul>
				</nav>
			</div>
			<img src="<?php echo base_url();?>pet store banner 5 png (1).png">
			<div class ="column right">
				
				<h2>My Pet</h2>
				<p>Required information is marked with an asterisk (*).</p>
				<br>

				<?php echo form_open('DataBusStore'); ?>  
					
					<?php if (isset($message)) { ?>
					<h3>Data inserted successfully!</h3><br>
					<?php } ?>
					<?php echo form_label('*Business Name  :'); ?> <?php echo form_error('bname'); ?><br />
					<?php echo form_input(array('id' => 'bname', 'name' => 'bname')); ?><br />

					<?php echo form_label('*Service  :'); ?> <?php echo form_error('service'); ?><br />
					<?php echo form_input(array('id' => 'service', 'name' => 'service')); ?><br />

					<?php echo form_submit(array('id' => 'submit', 'value' => 'Submit')); ?>
			
			<?php echo form_close(); ?>
				
				<footer>
            <i>Copyright &copy 2018 Pet Store</i><br>
            <a href="mailto:someone@example.com"> <i>amitesh@mathur.com</i></a>
        </footer>
			</div> 
		</div> 
	</div> 
	
</body>
</html>