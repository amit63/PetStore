<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	
	<title>Contact Us</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/pet.css">
</head>
<body>
<div id="wrapper">
	<h1>Pet Store</h1>
		<div class = "row">
			<div class = "column left">
				<nav>
					<ul>

      <li><a href="Home">Home</a></li>
        <li><a href="AboutUs">About Us</a></li>
        <li><a href="ContactUs">Contact Us</a></li>
        <li><a href="Client">Client</a></li>
        <li><a href="Service">Service</a></li>
        <li><a href="Login">Login</a></li>
		
		</ul>			
				</nav>	
			</div>
			<img src="<?php echo base_url();?>pet store banner 7 png.png">
			<div class ="column right">
				
				<h2>Contact Us.</h2>
				<p>Required information is marked with an asterisk (*).</p>
				<?php echo form_open('Datacontact'); ?>  
					
					<?php if (isset($message)) { ?>
					<h3>Comments have been recorded, We will contact you soon! </h3><br>
					<?php } ?>
					<?php echo form_label('*First Name:'); ?> <?php echo form_error('fname'); ?><br />
					<?php echo form_input(array('id' => 'fname', 'name' => 'fname')); ?><br />

					<?php echo form_label('* Last Name :'); ?> <?php echo form_error('lname'); ?><br />
					<?php echo form_input(array('id' => 'lname', 'name' => 'lname')); ?><br />

					<?php echo form_label('* Email  :'); ?> <?php echo form_error('email'); ?><br />
					<?php echo form_input(array('id' => 'email', 'name' => 'email')); ?><br />

					<?php echo form_label('* Phone  :'); ?> <?php echo form_error('phone'); ?><br />
					<?php echo form_input(array('id' => 'phone', 'name' => 'phone', 'placeholder' => 'The phone number entered is incorrect please enter a valid one!')); ?><br />

					<?php echo form_label('* Comments :'); ?> <?php echo form_error('comments'); ?><br />
					<?php echo form_input(array('id' => 'comments', 'name' => 'comments')); ?><br />

					<?php echo form_submit(array('id' => 'submit', 'value' => 'Submit')); ?>
					<?php echo form_close(); ?><br/>

				<footer>
            <i>Copyright &copy 2018 Pet Store</i><br>
            <a href="mailto:someone@example.com"> <i>amitesh@mathur.com</i></a>
        </footer>
			</div> 
		</div> 
	</div>
</body>
</html>