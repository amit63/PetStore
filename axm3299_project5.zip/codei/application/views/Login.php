<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/pet.css">
</head>
<body>
<div id="wrapper">
	<h1>Pet Store</h1>
		<div class = "row">
			<div class = "column left">
				<nav>
			<ul>

      <li><a href="Home">Home</a></li>
        <li><a href="AboutUs">About Us</a></li>
        <li><a href="ContactUs">Contact Us</a></li>
        <li><a href="Client">Client</a></li>
        <li><a href="Service">Service</a></li>
        <li><a href="Login">Login</a></li>
		
		</ul>	
				</nav>
			</div>
			<img src="<?php echo base_url();?>pet store banner 5 png (1).png">
			<div class ="column right">
				
				<h2>Login</h2>
				<p>Required information is marked with an asterisk (*).</p>
				<br>
				<?php echo form_open('Datalogin'); ?>  
			
					<?php echo form_label('*Email ID :'); ?> <?php echo form_error('email'); ?><br />
					<?php echo form_input(array('id' => 'email', 'name' => 'email')); ?><br />

					<?php echo form_label('*Password:'); ?><br />
					<?php echo form_input(array('id' => 'pwd', 'name' => 'pwd')); ?><br />

					<?php echo form_submit(array('id' => 'submit', 'value' => 'Submit')); ?>
			
			<?php echo form_close(); ?>

				<footer>
            <i>Copyright &copy 2018 Pet Store</i><br>
            <a href="mailto:someone@example.com"> <i>amitesh@mathur.com</i></a>
        </footer>
			</div> 
		</div> 
	</div> 
</body>
</html>