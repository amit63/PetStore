<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/pet.css">
</head>
<body>
<div id="wrapper">
	<h1>Pet Store</h1>
		<div class = "row">
			<div class = "column left">
				<nav>
										<ul>

      <li><a href="Home">Home</a></li>
        <li><a href="AboutUs">About Us</a></li>
        <li><a href="ContactUs">Contact Us</a></li>
        <li><a href="Client">Client</a></li>
        <li><a href="Service">Service</a></li>
        <li><a href="Login">Login</a></li>
		
		</ul>
				</nav>
			</div>
			<img src="<?php echo base_url();?>pet store banner 5 png (1).png">
			<div class ="column right">
				
				<h2>Enjoy your pets in our island.</h2>
				<p>Pet Store offers a special experience on dealing with your pet's needs on the island. Relax in serenity with our experts taking care of all your pet's need.</p>

				<ul>
					<li>Grooming.</li>
					<li>Vaccines.</li>
					<li>Implants.</li>
					<li>Dental cleaning.</li>
					<li>Travel documents.</li>
				</ul>

				<p>Pet store<br>1999 All Pets Road<br>Round Rock, TX 95555</p>
				<p>888-555-5555</p>
				<br>

				<footer>
            <i>Copyright &copy 2018 Pet Store</i><br>
            <a href="mailto:someone@example.com"> <i>amitesh@mathur.com</i></a>
        </footer>
			</div> 
		</div> 
	</div>
</body>
</html>