<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	
	<title>Client PetStore</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/pet.css">
</head>
<body>
<div id="wrapper">
	<h1>Pet Store</h1>
		<div class = "row">
			<div class = "column left">
				<nav>
				 <ul>

      <li><a href="Home">Home</a></li>
        <li><a href="AboutUs">About Us</a></li>
        <li><a href="ContactUs">Contact Us</a></li>
        <li><a href="Client">Client</a></li>
        <li><a href="Service">Service</a></li>
        <li><a href="Login">Login</a></li>
		
		</ul>			
				</nav>
			</div>
			<img src="<?php echo base_url();?>pet store banner 5 png (1).png">
			<div class ="column right">
				<h2>Client.</h2>
				<p>Required information is marked with an asterisk (*).</p>
				<?php echo form_open('Dataclient'); ?>  
					
					<?php if (isset($message)) { ?>
			<h3> You have successfully been signed up as a client!! </h3><br>
					<?php } ?>
					<?php echo form_label('*First Name  :'); ?> <?php echo form_error('fname'); ?><br />
					<?php echo form_input(array('id' => 'fname', 'name' => 'fname')); ?><br />

					<?php echo form_label('*Last Name  :'); ?> <?php echo form_error('lname'); ?><br />
					<?php echo form_input(array('id' => 'lname', 'name' => 'lname')); ?><br />

					<?php echo form_label('*Email  :'); ?> <?php echo form_error('email'); ?><br />
					<?php echo form_input(array('id' => 'email', 'name' => 'email')); ?><br />

					<?php echo form_label('*Phone  :'); ?> <?php echo form_error('phone'); ?><br />
					<?php echo form_input(array('id' => 'phone', 'name' => 'phone', 'placeholder' => 'The phone number entered is incorrect please enter a valid one!')); ?><br />

					<?php echo form_label('Business Name :'); ?> <?php echo form_error('businessname'); ?><br />
					<?php echo form_input(array('id' => 'bname', 'name' => 'bname')); ?><br />

					<?php echo form_submit(array('id' => 'submit', 'value' => 'Submit')); ?>
			
			<?php echo form_close(); ?>
				<br><br><br>

				<footer>
            <i>Copyright &copy 2018 Pet Store</i><br>
            <a href="mailto:someone@example.com"> <i>amitesh@mathur.com</i></a>
        </footer>
			</div> 
		</div> 
	</div>
</body>
</html>