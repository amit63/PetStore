<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>About Us</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/pet.css">
	</head>
<body>
<div id="wrapper">
	<table id = "about">
	<tr>
	<td colspan="2">
	<h1>About us</h1>
	</td>
	</tr>

	<tr>
	<td width="20%" valign="top" bgcolor="#90C7E3" style="padding-top: 15px; padding-left: 15px;">
	<nav>
		<ul>

      <li><a href="Home">Home</a></li>
        <li><a href="AboutUs">About Us</a></li>
        <li><a href="ContactUs">Contact Us</a></li>
        <li><a href="Client">Client</a></li>
        <li><a href="Service">Service</a></li>
        <li><a href="Login">Login</a></li>
		
		</ul>
	</nav>
	</td>

	<td width="80%" valign="top">
	<img src="<?php echo base_url();?>pet store banner 6 png.png">
				<h2>About us</h2>
				We specialize in offering site services to PetStore. We offer a one stop service for clients and businesses. Pet store offers a special experience on dealing with your pet's needs on the Island. Relax in serenity with our experts taking care of all your pet's needs.
				<br><br><br>

				Pet store
				<br>1999 All Pets Road
				<br>Round Rock, TX 95555
				<br><br><br>
				888-555-5555
				<br>
			</td>
		</tr>

		<tr><td colspan="2" align="center" height="20">

					<footer>
            <i>Copyright &copy 2018 Pet Store</i><br>
            <a href="mailto:someone@example.com"> <i>amitesh@mathur.com</i></a>
        </footer>
			</td>
		</tr>
	</table>
</div>
</html>