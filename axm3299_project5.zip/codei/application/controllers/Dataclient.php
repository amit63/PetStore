<?php

class Dataclient extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('clientModel');
	}

	function index() {

		$this->load->library('form_validation');

		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		$this->form_validation->set_rules('fname', 'Username', 'required|min_length[2]|max_length[20]');

		$this->form_validation->set_rules('lname', 'Username', 'required|min_length[2]|max_length[20]');

		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

		$this->form_validation->set_rules('phone', 'Mobile No.', 'required|regex_match[/^[0-9]{10}$/]');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('Client');
		} 

		else {
			$data = array(
			'fname' => $this->input->post('fname'),
			'lname' => $this->input->post('lname'),
			'email' => $this->input->post('email'),
			'phone' => $this->input->post('phone'),
			'bname' => $this->input->post('bname')
			);

			$dataLogin = array(
			'fname' => $this->input->post('fname'),
			'lname' => $this->input->post('lname'),
			'email' => $this->input->post('email'),
			'pwd' => '55555',
			'rollid' => '0'
			);

			$this->clientModel->insertClient($data);
			$this->clientModel->insertClientLogin($dataLogin);
			$data['message'] = 'You have been signed up succesfully!!';
			$this->load->view('client', $data);
		}
	}

}

?>