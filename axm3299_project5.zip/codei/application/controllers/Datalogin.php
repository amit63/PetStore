<?php

class Datalogin extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('loginModel');
	}

	function index() {

		$this->load->library('form_validation');

		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

		$this->form_validation->set_rules('pwd', 'Password', 'required|min_length[2]|max_length[10]');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('login');
		} 

		else {
			
			$email = $this->input->post('email');
			
			$this->loginModel->getlogin($email);
			$this ->db->where('email',$email);
			
			
		}
	}

}

?>