<?php 
   class Home BusStore CI_Controller {
  
      public function index() {
      	 $this->load->helper('url');
        $this->load->view('busstore'); 
      } 
   } 
?>