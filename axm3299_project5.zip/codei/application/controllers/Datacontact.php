<?php

class Datacontact extends CI_Controller 
{
		function __construct() 
		{
				parent::__construct();
				$this->load->model('contactModel');
		}
		
		function index() {

		$this->load->library('form_validation');

		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		$this->form_validation->set_rules('fname', 'Username', 'required|min_length[2]|max_length[20]');

		$this->form_validation->set_rules('lname', 'Username', 'required|min_length[2]|max_length[20]');

		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

		$this->form_validation->set_rules('phone', 'Mobile No.', 'required|regex_match[/^[0-9]{10}$/]');

		$this->form_validation->set_rules('comments', 'Address', 'required|min_length[15]|max_length[150]');

		if ($this->form_validation->run() == FALSE) {
				$this->load->view('contactus');
		} 

		else {
				$data = array(
		'fname' => $this->input->post('fname'),
		'lname' => $this->input->post('lname'),
		'email' => $this->input->post('email'),
		'phone' => $this->input->post('phone'),
		'comment' => $this->input->post('comments')
		);

		$this->contactModel->insertContact($data);
		$data['message'] = 'Thank you for the comments, We will get back to you soon!!';
		$this->load->view('contactus', $data);
		}
	}

}

?>