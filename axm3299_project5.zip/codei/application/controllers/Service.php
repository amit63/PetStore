<?php 
   class Service extends CI_Controller {
  
      public function index()
       {
      	$this->load->helper('url');
        $this->load->view('service');
      }

       public function callModel()
       {
      	$this->load->model('servicemodel');
      }

      public function addBusiness()
      {
      	$this->load->model('servicemodel');

      	$data = array('fname' => $this->input->post('fname'), 
      				'lname' => $this->input->post('lname'),
      				'phone' => $this->input->post('phone'),
      				'email' => $this->input->post('email'),
      				'bname' => $this->input->post('bname'),
      				'services' => "");
      	$this->load->database();
      	$this->ServiceModel->insert($data);
      }

      public function addServicelogin()
      {
         $this->load->model('servicemodel');

         $dataLogin = array('fname' => $this->input->post('fname'), 
                            'lname' => $this->input->post('lname'),
                           'email' => $this->input->post('email'),
                           'pwd' => "55555",
                           'rollid' => "1");
         $this->load->database();
         $this->ServiceModel->insertServiceLogin($dataLogin);
      } 
   } 
?>