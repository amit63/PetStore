<?php

class DataBusStore extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('BusStoreModel');
	}

	function index() {

		$this->load->library('form_validation');

		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		$this->form_validation->set_rules('bname', 'Username', 'required|min_length[3]|max_length[20]');

		$this->form_validation->set_rules('service', 'Username', 'required|min_length[2]|max_length[20]');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('BusStore');
		} 

		else {
			$data = array(
			'services' => $this->input->post('service'),
			'bname' => $this->input->post('bname')
			);

			$this->busStoreModel->insertService($data);
			$data['message'] = 'Data has been recorded as a service';
			$this->load->view('busStore', $data);
		}
	}

}

?>